document.addEventListener('DOMContentLoaded', function () {
    const slotsTable = document.getElementById('slots-table').getElementsByTagName('tbody')[0];
    const bookedSlotsTable = document.getElementById('booked-slots-table').getElementsByTagName('tbody')[0];
    const bookingForm = document.getElementById('booking-form');
    const form = document.getElementById('form');

    // Fetch slots data from the server
    async function fetchSlots() {
        const response = await fetch('/'); // Adjust the endpoint if necessary
        const data = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');
        const slots = Array.from(doc.getElementById('slots-table').getElementsByTagName('tbody')[0].children).map(row => ({
            date: row.cells[1].innerText,
            time: row.cells[2].innerText,
            status: row.cells[3].innerText.toLowerCase()
        }));
        return slots;
    }

    const bookedSlots = [];

    // Populate slots table
    async function populateSlotsTable() {
        const slots = await fetchSlots();
        slotsTable.innerHTML = ''; // Clear existing entries
        slots.forEach((slot, index) => {
            const row = slotsTable.insertRow();
            row.insertCell(0).innerText = index + 1; // Slot Number
            row.insertCell(1).innerText = slot.date; // Date
            row.insertCell(2).innerText = slot.time; // Time
            row.insertCell(3).innerText = slot.status.charAt(0).toUpperCase() + slot.status.slice(1); // Status

            const actionCell = row.insertCell(4);
            if (slot.status === 'available') {
                const bookButton = document.createElement('button');
                bookButton.innerText = 'Book';
                bookButton.onclick = () => openBookingForm(slot, index + 1);
                actionCell.appendChild(bookButton);
            } else {
                actionCell.innerText = 'Booked';
            }
        });
    }

    // Open booking form with selected slot details
    function openBookingForm(slot, slotNumber) {
        document.getElementById('slot-date').value = slot.date;
        document.getElementById('slot-time').value = slot.time;
        document.getElementById('slot-number').value = slotNumber;
        bookingForm.classList.remove('hidden');
        window.scrollTo(0, document.body.scrollHeight);
    }

    // Handle form submission
    form.onsubmit = async (e) => {
        e.preventDefault();

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const slotNumber = document.getElementById('slot-number').value;
        const slotDate = document.getElementById('slot-date').value;
        const slotTime = document.getElementById('slot-time').value;

        // Input validation
        if (!name || !email || !phone) {
            alert("Please fill in all fields.");
            return;
        }

        // Send booking request to server
        const response = await fetch('/book_slot', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, phone, date: slotDate, time: slotTime, slot_number: slotNumber })
        });

        if (response.ok) {
            const result = await response.json();
            if (result.success) {
                // Mark slot as booked in the local data and update the tables
                await populateSlotsTable(); // Refresh the slots table
                resetForm();
                alert("Your booking is confirmed!");
            }
        } else {
            const errorResult = await response.json();
            alert(errorResult.message);
        }
    };

    // Update booked slots table
    async function updateBookedSlotsTable() {
        const response = await fetch('/bookings'); // Adjust this endpoint to fetch booked slots from the server
        const bookedSlots = await response.json();
        bookedSlotsTable.innerHTML = ''; // Clear existing entries
        bookedSlots.forEach(slot => {
            const row = bookedSlotsTable.insertRow();
            row.insertCell(0).innerText = slot.name;
            row.insertCell(1).innerText = slot.email;
            row.insertCell(2).innerText = slot.phone;
            row.insertCell(3).innerText = slot.date;
            row.insertCell(4).innerText = slot.time;
            row.insertCell(5).innerText = slot.slot_number;
        });
    }

    // Reset form after submission
    function resetForm() {
        form.reset(); // Clear input fields in the form
        bookingForm.classList.add('hidden'); // Hide the booking form after submission
    }

    populateSlotsTable(); // Initialize slots table on page load
    updateBookedSlotsTable(); // Load booked slots
});
