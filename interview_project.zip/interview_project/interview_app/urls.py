# urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.open_page, name='home'),
    path('register/', views.register, name='register'),
    path('application/', views.application, name='application'),
    path('book-slot/', views.book_slot, name='book_slot'),
    path('first-round/', views.first_round, name='first_round'),
    path('second-round/', views.second_round, name='second_round'),
    path('timeline/', views.timeline, name='timeline'),
    path('slot-booking/', views.slot_booking, name='slot_booking'),  # Added route for slot booking
    ]
