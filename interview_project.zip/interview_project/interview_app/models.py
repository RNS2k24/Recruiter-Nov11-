from djongo import models

# Candidate model to store registration details and interview status
class Candidate(models.Model):
    _id = models.ObjectIdField(primary_key=True)
    email = models.EmailField(unique=True)
    registered = models.BooleanField(default=False)
    job_role = models.CharField(max_length=255, blank=True, null=True)
    application_submitted = models.BooleanField(default=False)
    first_round = models.BooleanField(default=False)
    second_round = models.BooleanField(default=False)
    interview_slot_booked = models.BooleanField(default=False)

    class Meta:
        db_table = 'candidates'

    def __str__(self):
        return self.email

# Slot model for storing available interview slots
class Slot(models.Model):
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(max_length=10, default='available')
    slot_number = models.IntegerField()

    class Meta:
        db_table = 'slots'

    def __str__(self):
        return f"Slot {self.slot_number} on {self.date} at {self.time}"

# Booking model to store booking information
class Booking(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    date = models.DateField()
    time = models.TimeField()
    slot_number = models.IntegerField()
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)

    class Meta:
        db_table = 'bookings'

    def __str__(self):
        return f"Booking for {self.name} ({self.slot_number}): {self.date} at {self.time}"
