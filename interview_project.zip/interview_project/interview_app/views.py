from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.db import DatabaseError
from .models import Candidate, Slot, Booking
import logging
import os

# Set up logging
logger = logging.getLogger(__name__)

# Email configuration from environment variables
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "kandaring2k24@gmail.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "wvbi llnr quyd fejl")

# Register or update a candidate
def register_candidate(email):
    candidate, created = Candidate.objects.get_or_create(email=email)
    if created:
        candidate.registered = True
        candidate.save()
    return candidate

# Update the candidate's field (first or second round status)
def update_candidate_field(email, field, value=True):
    try:
        candidate = Candidate.objects.filter(email=email).first()
        if candidate:
            setattr(candidate, field, value)
            candidate.save()
            return True
        return False
    except Exception as e:
        logger.error(f"Error updating candidate field: {e}")
        return False

# Send email function (confirmation or notification)
def send_confirmation_email(to_email, subject, template_name, context):
    html_content = render_to_string(template_name, context)
    send_mail(
        subject,
        '',
        SMTP_USERNAME,
        [to_email],
        html_message=html_content,
    )

# Home page redirect to registration
def open_page(request):
    return redirect('register')

# Registration page for candidates
def register(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        if email:
            candidate = register_candidate(email)
            messages.success(request, "Registration successful!")
    return render(request, 'register.html')

# Application submission page
def application(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        job_role = request.POST.get('job_role')

        try:
            candidate = register_candidate(email)
            candidate.job_role = job_role
            candidate.application_submitted = True
            candidate.save()
            messages.success(request, 'Application submitted successfully!')
        except DatabaseError as e:
            error_message = f"Database error occurred: {str(e)}"
            messages.error(request, error_message)
            logger.error(error_message)

    return render(request, 'application.html')

# Slot booking page and handling
def book_slot(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        slot_number = request.POST.get('slot_number')
        slot_date = request.POST.get('slot_date')
        slot_time = request.POST.get('slot_time')

        if Booking.objects.filter(email=email).exists():
            return JsonResponse({'success': False, 'message': "This email has already booked a slot."}, status=400)

        # Check if slot is available
        slot = Slot.objects.filter(date=slot_date, time=slot_time, status='available').first()
        if slot:
            slot.status = 'booked'
            slot.save()

            # Save the booking
            candidate = register_candidate(email)
            Booking.objects.create(
                name=name,
                email=email,
                phone=phone,
                date=slot_date,
                time=slot_time,
                slot_number=slot_number,
                candidate=candidate
            )

            # Send confirmation email
            context = {'name': name, 'date': slot_date, 'time': slot_time, 'slot_number': slot_number}
            send_confirmation_email(email, "Slot Booking Confirmation", 'confirm.html', context)
            return JsonResponse({'success': True})

        return JsonResponse({'success': False, 'message': "This slot is already booked or does not exist."}, status=400)

# First round of interview
def first_round(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        if update_candidate_field(email, 'first_round', True):
            messages.success(request, "First round completed!")
        else:
            messages.error(request, "Error: Email not found. Please register first.")
        return redirect('first_round')
    return render(request, 'first_round.html')

# Second round of interview
def second_round(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        if update_candidate_field(email, 'second_round', True):
            messages.success(request, "Second round completed!")
        else:
            messages.error(request, "Error: Email not found. Please register first.")
        return redirect('second_round')
    return render(request, 'second_round.html')

# View timeline of candidate's rounds
def timeline(request):
    if request.method == 'POST':
        # Get the email from the POST data
        email = request.POST.get('email')
        
        if email:
            try:
                # Try to fetch the candidate by email
                candidate = Candidate.objects.get(email=email)
                # Render the timeline page for the found candidate
                return render(request, 'timeline_search.html', {'candidate': candidate})
            except Candidate.DoesNotExist:
                # Show an error message if candidate is not found
                messages.error(request, "Candidate not found with this email.")
                return redirect('timeline')  # Redirect back to the timeline page if not found
        else:
            # Show an error message if email is not provided
            messages.error(request, "Please provide an email.")
            return redirect('timeline')

    # Handle GET request - Just render the search page
    return render(request, 'timeline_search.html')


# Slot booking page
def slot_booking(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        slot_date = request.POST['slot_date']
        slot_time = request.POST['slot_time']
        slot_number = request.POST['slot_number']

        # Find the corresponding Slot object
        slot = Slot.objects.get(date=slot_date, time=slot_time, slot_number=slot_number)

        # Create the booking (ensure candidate exists)
        candidate = register_candidate(email)
        Booking.objects.create(
            name=name,
            email=email,
            phone=phone,
            date=slot_date,
            time=slot_time,
            slot_number=slot_number,
            candidate=candidate
        )

        # Update slot status
        slot.status = 'booked'
        slot.save()

        return redirect('slot_booking')  # Redirect to the same page or to a confirmation page

    slots = Slot.objects.filter(status='available')
    return render(request, 'slot_booking.html', {'slots': slots})
